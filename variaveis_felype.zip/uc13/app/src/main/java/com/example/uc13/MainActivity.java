package com.example.uc13;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void Vint (View view) {

        EditText textInt = findViewById(R.id.Vint);

        int numeros = 0;
        numeros = Integer.parseInt(textInt.getText().toString());

        Toast.makeText(this,"O inteiro é: "+ numeros, Toast.LENGTH_SHORT).show();
    }
public void Vdouble (View view){

        EditText VDouble = findViewById(R.id.Vdouble);
                double valor = 0;
        valor = Double.parseDouble(VDouble.getText().toString());
    Toast.makeText(this, "O Double é: "+ valor, Toast.LENGTH_SHORT).show();
}
public void Vstring (View view){

        EditText Vstring = findViewById(R.id.Vstring);
       String texto = "String344ff4343234234";
       Toast.makeText(this, "O texto escrito é:"+texto, Toast.LENGTH_SHORT).show();

    }

}